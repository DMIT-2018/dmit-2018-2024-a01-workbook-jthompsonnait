﻿#nullable disable
namespace PassingObjects.Data
{
    public class AppState
    {
        public EmployeeView EmployeeView { get; set; }
    }
}
